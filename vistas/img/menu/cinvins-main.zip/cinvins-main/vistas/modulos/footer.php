<footer class="main-footer">
	
	<strong>Copyright &copy; 2017 <a target="_blank">Sistema de Inventarios Cinvins</a>. 
	</strong>

	Todos los derechos reservados.
	
</footer>